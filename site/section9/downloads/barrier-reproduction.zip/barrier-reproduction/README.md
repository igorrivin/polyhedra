# Section 9 barrier reproduction

This is a labeled numerical subset, not the complete toolkit. Maintained angle_barrier.py, variational.py and geometry.py are copied unchanged; the original MIT license is under LICENSES. The captured computation used CPython 3.12.11. Other runtimes are not validated by that record.

From this extracted directory install `python -m pip install -r requirements.txt`, then run `python experiments/section9/barrier_run.py`. An absolute script path works from another working directory. Outputs default to artifacts/section9/barrier-result.json and site/section9/barrier.html. The fixed fixtures include independent 80-digit reference comparisons. Reported gap estimates are not interval certificates, and this dense solver is not a nearly-linear implementation.

The monograph assets are optional and absent. Detached Git status is unavailable; barrier-bundle.json retains origin provenance and verifies every payload hash. Rendering an existing report preserves its computation versions and timestamp. Inspection downloads are not standalone programs; use this ZIP.
