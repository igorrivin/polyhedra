"""Generated Section 9 barrier subset; not the complete toolkit API.
Maintained numerical modules are copied unchanged; see barrier-bundle.json.
"""
