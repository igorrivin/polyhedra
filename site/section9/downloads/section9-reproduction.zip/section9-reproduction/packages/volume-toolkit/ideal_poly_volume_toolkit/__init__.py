"""Generated Section 9 numerical subset; not the complete toolkit API.
Original maintained modules are copied unchanged. See LICENSES and section9-bundle.json.
"""
