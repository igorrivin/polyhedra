# Section 9 reproduction bundle

This is a generated numerical subset of the Ideal Polyhedra Volume Toolkit, with its maintained variational.py and geometry.py copied unchanged. It is not a full toolkit distribution: Torch, rendering, RL and unrelated APIs are excluded. The original MIT license is in LICENSES/volume-toolkit-MIT.txt. The numerical reproduction needs only NumPy, SciPy and mpmath.

The captured reproduction used CPython 3.12.11; other Python/platform combinations were not validated for this bundle. From this extracted directory, install dependencies with `python -m pip install -r requirements.txt`, then run `python experiments/section9/run.py`. An absolute runner path also works from another working directory; the runner finds this explicitly labeled bundled subset. No development checkout is needed.

Outputs default to artifacts/section9/result.json and site/section9/index.html. The optional --fixture argument accepts only an unchanged copy of the supplied fixture. The monograph source/PDF are not included and are explicitly reported unavailable; their absence does not prevent this finite computation or its companion rendering. This bundle does not verify the full monograph.

section9-bundle.json records originating source provenance and every payload hash. A detached run has no Git clean/dirty state and records that as unavailable. The original source snapshot may itself have been dirty; that status remains in origin_provenance.
