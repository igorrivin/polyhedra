# Complete canonical monograph LaTeX source

From book/, run `latexmk -norc -pdf main.tex` for the full monograph or `latexmk -norc -pdf section9.tex` for the generated Section 9 excerpt. The preamble and selected bibliography in section9.tex are generated from the canonical full source. External Section 16 equations are reference-only, outside this chapter review. Canonical chapter source is unchanged; repository-relative hyperlinks need the repository/companion. The separately distributed chapter PDF rewrites only those link targets for its downloads directory.
